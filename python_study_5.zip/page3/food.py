from menu_item import MenuItem

class Food(MenuItem):
    pass

# Tetapkan 'Bob' ke variable name
name = 'Bob'

# Cetak nilai dari variable name
print(name)

# Tetapkan 7 ke variable number
number = 7

# Cetak nilai dari variable number
print(number)
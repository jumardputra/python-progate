apple_price = 2
apple_count = 8

# Berikan hasil dari apple_price * apple_count ke variable total_price 
total_price = apple_price * apple_count

# Cetak nilai dari variable total_price 
print(total_price)
